from selenium import webdriver
from selenium.webdriver.common.proxy import Proxy, ProxyType

proxy = "188.158.120.33:8080" # IP:PORT or HOST:PORT

myProxy = proxy

proxy = Proxy({
    'proxyType': ProxyType.MANUAL,
    'httpProxy': myProxy,
    'ftpProxy': myProxy,
    'sslProxy': myProxy,
    'noProxy': '' # set this value as desired
    })
driver = webdriver.Firefox(proxy=proxy)
driver.get("http://www.google.com")
