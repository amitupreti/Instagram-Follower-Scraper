from selenium import webdriver
from selenium.webdriver.common.proxy import Proxy, ProxyType
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
options = webdriver.ChromeOptions()
import random
import pandas as pd
from selenium.common.exceptions import NoSuchElementException
import csv

delay = 10 # seconds



proxlist = pd.read_csv('list.txt')
proxlist = proxlist.values
# print('3128' in str(proxlist[0]))
#proxlist= [ i for i in proxlist if '8080' in str(i)]
print(len(proxlist))
output='test.csv'

with open(output,'w',newline='') as csvf:
    csv_writer = csv.writer(csvf)
    csv_writer.writerow(['category','sub_category','sub_sub_category','course_title','instructor_name','facebook','twitter','linkedin','website','youtube'])




def changeproxy(link):
    p=random.choice(proxlist)
    print('Using Proxy: ',p[0])
        

    proxy = p[0].strip()# IP:PORT or HOST:PORT

    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--proxy-server=%s' % proxy)
    chrome_options.add_argument("--start-maximized")
    chrome_options.add_argument('--ignore-certificate-errors')

    driver = webdriver.Chrome(chrome_options=chrome_options)
    
    try:
        driver.get(link)
    except:
        print('60 seconds passed stopping')
    return driver 



def send_link(link):
    print('Visiting',link)
    driver = changeproxy(link)
    print('proxy applied')
    driver.find_element_by_xpath('//*[@class="instructor-links__link"]').text
    try:        
        driver.find_element_by_xpath('//*[@class="instructor-links__link"]').text

        
    except Exception as e:
        print('Faulty proxy\nUsing new proxy\n',e)
        print('Waiting for interruption')
        input()
        driver.close()
        send_link(link)


    return driver



def scrape(link):
    
    try:
        driver = send_link(link)
        cat=driver.find_elements_by_xpath('//*[@data-purpose="topic-menu-item"]')
        category=cat[0].text
        sub_category=cat[1].text
        sub_sub_category=cat[2].text
        print('category:',category)
        print('subsubcategory',sub_sub_category)
        course_title = driver.find_element_by_xpath('//h1').text
        print('Course title',course_title)
        instructor_name = driver.find_element_by_xpath('//*[@class="instructor-links__link"]').text
        print('Instructor Name:',instructor_name)
        try:
            driver.find_element_by_xpath('//*[@class="fx"]/div/div/a').click()
        except Exception as e:
            print(e)
            
        # sleep(3)
        try:
            myElem = WebDriverWait(driver, delay).until(EC.presence_of_element_located((By.XPATH, '//*[@class="instructor__social"]/a')))
            print ("Page is ready!")
        except TimeoutException:
            print ("Loading took too much time!")

        contact = [i.get_attribute('href') for i in driver.find_elements_by_xpath('//*[@class="instructor__social"]/a')]
        facebook=twitter=linkedin=website=youtube=''
        for i in contact:
            if 'facebook' in i:
                facebook = i
            elif 'twitter' in i:
                twitter = i
            elif 'linkedin' in i:
                linkedin = i

            elif '.com' in i:
                website = i
            
            elif 'youtube' in i:
                youtube = i


        with open(output,'a',newline='') as csvf:
            csv_writer = csv.writer(csvf)
            csv_writer.writerow([category,sub_category,sub_sub_category,course_title,instructor_name,facebook,twitter,linkedin,website,youtube])

        driver.close()
        print('Facebook',facebook,'\ntwitter',twitter,'\nlinkedin',linkedin,'\nwebsite:',website,'youtube:',youtube)
        #print(category,sub_category,sub_sub_category,course_title,instructor_name,facebook,twitter,linkedin,website,youtube)
        input()
    except NoSuchElementException as e:
       
        print("Bot detected\n")

        driver.close()
        scrape(link)


scrape('https://www.udemy.com/advanced-javascript-concepts/')
